udm14
=====

Search engine add-on so that the udm=14 parameter is automatically included in Google searches.

As of 22 May 2024, this parameter requests Google to return a more stripped down view for search results, omitting much of the additional junk inserted by allegedly AI processes.

This add-on was created solely to make it easier for me to use this parameter for default search. Uploaded in case it is of use to others.